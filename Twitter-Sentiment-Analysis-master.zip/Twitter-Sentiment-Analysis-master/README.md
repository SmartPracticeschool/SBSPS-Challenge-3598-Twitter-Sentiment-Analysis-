# Twitter-Sentiment-Analysis
The ongoing pandemic has affected lives of millions around the world. It has been observed that people have used social media to give voice to their emotions. In order to analyze them, Sentiment Analysis on tweets is probably the best way to understand the ongoing circumstances. Based on the tweets on Covid19, our team aspires to build dashboards for daily monitoring of the results.




